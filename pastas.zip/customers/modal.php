			<!-- Modal -->
			<div class="modal fade" id="delete-modal-cliente" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog">
			    <div class="modal-content">
			      <div class="modal-header">
			        <h1 class="modal-title fs-5" id="exampleModalLabel">Excluir cliente</h1>
			        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			      </div>
			      <div class="modal-body">
			        <p>Tem certeza que deseja excluir este cliente?</p>
			      </div>
			      <div class="modal-footer">
			        <a class="btn btn-primary" id="confirm" href="#"><i class="fa-regular fa-circle-check"></i> Sim</a>
			        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><i class="fa-solid fa-xmark"></i> Não</button>
			      </div>
			    </div>
			  </div>
			</div>
