			<!-- Modal -->
			<div class="modal fade" id="delete-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog">
				<div class="modal-content">
				  <div class="modal-header">
					<h1 class="modal-title fs-5" id="exampleModalLabel">Excluir Imóvel</h1>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				  </div>
				  <div class="modal-body">
					<h5>Deseja realmente excluir este imóvel?</h5>
				  </div>
				  <div class="modal-footer">
					<a type="button" class="btn btn-primary" id="confirm" href="#">
					<i class="fa-solid fa-check"></i> Sim
					</a>
					<button type="button" class="btn btn-info text-light" data-bs-dismiss="modal">
					<i class="fa-solid fa-xmark"></i>
					 Não</button>
				  </div>
				</div>
			  </div>
			</div>